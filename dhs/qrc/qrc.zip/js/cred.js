// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyCw1QFDvNxX5_qEB6loNlU1H26YRq9Kdh8",
    authDomain: "qreward-converter.firebaseapp.com",
    databaseURL: "https://qreward-converter-default-rtdb.firebaseio.com",
    projectId: "qreward-converter",
    storageBucket: "qreward-converter.appspot.com",
    messagingSenderId: "89182545361",
    appId: "1:89182545361:web:4c5c058f92d13123272cf0",
    measurementId: "G-X3LF5JNPCN"
  };
   firebase.initializeApp(firebaseConfig); 